fx_version 'cerulean'
game 'gta5'

author 'HeresJohnny320 (https://github.com/HeresJohnny320/fivem-resource-file-watcher)'
description 'restarts any resource'
version '1.0.0'


server_script 'server.js'